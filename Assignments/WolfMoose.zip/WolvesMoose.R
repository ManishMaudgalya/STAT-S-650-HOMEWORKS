# Read in your data from excell, saved as a dos text file

library(readxl)
TSdata = read_excel("/Users/jeromebusemeyer/Documents/Classes/TimeSeries/DataFiles/WolvesMoose.xlsx")

# load('ZZ104.RData')

Wolves = TSdata$wolves
Moose = TSdata$moose

par(mfrow=c(2,1))
plot(Wolves,type='b',xlab="time")
plot(Moose,type="b",xlab="time")

ws= 10
b = rep(1/ws,ws)
# hrf = filter(hr, b, method="convolution",  sides = 2)
fWolves = filter(Wolves, b,  sides = 2)
# set sides = 1 for impulse response model
# set sides = 2 for two sided filter model
fMoose = filter(Moose, b,  sides = 2)

M1 = cbind(fWolves,fMoose)
plot(M1,type="l",xlab="time")

M2 = matrix(M1,61,2)
plot(M2,type="l",xlab="Wolves",ylab="Moose")

par(mfrow=c(3,1))
acf(Wolves, 10, main="output")
acf(Moose, 10, main="input")
ccf(Moose,Wolves,10, main="Output vs Input", ylab="CCF")
# cov of Moosse(t+k) with Wolves(t) at lag k
# first var at t+k, second var at t for lag k


# Polynomial regression analysis
N = 61
time = 1:N
mt = mean(time)
time = time-mt
T2 = time^2
T3 = time^3
res1 = lm(Moose~time+T2+T3)

# linear regression output
res1
summary(res1)
anova(res1)
coef(res1)


MooseRes1 = residuals(res1)

plot(MooseRes1,type="l",xlab="time")
acf(MooseRes1, 10, main="output")

# Polynomial regression analysis

res2 = lm(Moose~Wolves)

# linear regression output
res2
summary(res2)
anova(res2)
coef(res2)


MooseRes2 = residuals(res2)

plot(MooseRes2,type="l",xlab="time")
acf(MooseRes2, 10, main="output")

B = c(1,-1)
dMoose =  filter(Moose,B,sides=1)
dMoose = dMoose[2:61]
plot(dMoose)
acf(dMoose, 10, main="output")
